<?php $__env->startSection('title','Log In'); ?>
<?php $__env->startSection('main_content'); ?>
<div class="container ">

    <?php
    if (Session::get('message')) {
        ?>
        <div class="alert alert-dismissible alert-warning">
            <button type="button" class="close" data-dismiss="alert">&times;</button>
            <p><?php echo e(Session::get('message')); ?></p>
        </div>
    <?php } ?>

    <?php echo Form::open(['url' => '/log-in-check', 'method'=>'POST', 'class' => 'form-horizontal']); ?>

    <fieldset>
        <legend>Log In</legend>
        <div class="col-lg-5 col-lg-offset-3">
            <div class="form-group">
                <label for="exampleInputEmail1">Email address</label>
                <input name="email" type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email">
            </div>

            <div class="form-group">
                <label for="exampleInputPassword1">Password</label>
                <input name="password" type="password" class="form-control" id="exampleInputPassword1" placeholder="Password">
            </div>

            <button type="submit" class="btn btn-primary col-lg-offset-10">Submit</button>
        </div>
    </fieldset>
    <?php echo Form::close(); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>