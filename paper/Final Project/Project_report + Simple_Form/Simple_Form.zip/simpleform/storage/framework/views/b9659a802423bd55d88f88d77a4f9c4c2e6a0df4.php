<?php $__env->startSection('title','Log In'); ?>
<?php $__env->startSection('main_content'); ?>
<div class="container">
    <div class="col-md-12">
        <div class="row">
            <div class="well" style="background-color: green; color: white; font-weight: bold;">
    <h3>Welcome To User Dashboard.</h3>
</div>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>