<?php $__env->startSection('title','Log In'); ?>
<?php $__env->startSection('main_content'); ?>
<div class="container">


    <table class="table table-striped table-hover ">
        <thead>
            <tr>
                <th>Admin Name</th>
                <th>Admin Email</th>
                <th>DOB</th>
                <th>Acces Lavel</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $userAlldatas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $userAlldata): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($userAlldata->user_name); ?></td>
                <td><?php echo e($userAlldata->user_email); ?></td>
                <td><?php echo e($userAlldata->dob); ?></td>
                <td><?php echo e($userAlldata->acces_lavel); ?></td>
                <td>
                    <a href="" class="btn btn-success btn-hover  btn-sm">Edit</a>
                    <a href="" class="btn btn-danger btn-hover  btn-sm">Delete</a>
                </td>

            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>