<?php $__env->startSection('title','Registration'); ?>
<?php $__env->startSection('main_content'); ?>

<div class="container ">

    <?php
    if (Session::get('message')) {
        ?>
        <div class="alert alert-dismissible alert-warning">
            <button type="button" class="close" data-dismiss="alert">&times;</button>
            <p><?php echo e(Session::get('message')); ?></p>
        </div>
    <?php } ?>

    <?php echo Form::open(['url' => '/save-registration', 'method'=>'POST', 'class' => 'form-horizontal']); ?>

    <fieldset>
        <legend>Registration</legend>
        <div class="col-lg-5 col-lg-offset-3">
            <div class="form-group">
                <label for="exampleInputEmail1">Full Name</label>
                <input type="text" name="name" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email">
            </div>

            <div class="form-group">
                <label for="exampleInputPassword1">Email Address</label>
                <input type="email" name="email" class="form-control" id="exampleInputPassword1" placeholder="Password">
            </div>

            <div class="form-group">
                <label for="exampleInputPassword1">Date of Birth</label>
                <input type="date" name="dob" class="form-control" id="exampleInputPassword1" placeholder="Password">
            </div>

            <div class="form-group">
                <label for="exampleInputPassword1">Password</label>
                <input type="password" name="password" class="form-control" id="exampleInputPassword1" placeholder="Password">
            </div>

            <button type="submit" class="btn btn-primary col-lg-offset-9">Registration</button>
        </div>
    </fieldset>
    <?php echo Form::close(); ?>

</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>