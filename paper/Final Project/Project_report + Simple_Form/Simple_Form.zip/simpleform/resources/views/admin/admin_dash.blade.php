@extends('index')
@section('title','Log In')
@section('main_content')
<div class="container">


    <table class="table table-striped table-hover ">
        <thead>
            <tr>
                <th>Admin Name</th>
                <th>Admin Email</th>
                <th>DOB</th>
                <th>Acces Lavel</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            @foreach($userAlldatas as $userAlldata)
            <tr>
                <td>{{$userAlldata->user_name}}</td>
                <td>{{$userAlldata->user_email}}</td>
                <td>{{$userAlldata->dob}}</td>
                <td>{{$userAlldata->acces_lavel}}</td>
                <td>
                    <a href="" class="btn btn-success btn-hover  btn-sm">Edit</a>
                    <a href="" class="btn btn-danger btn-hover  btn-sm">Delete</a>
                </td>

            </tr>
            @endforeach

        </tbody>
    </table>
</div>
@endsection

