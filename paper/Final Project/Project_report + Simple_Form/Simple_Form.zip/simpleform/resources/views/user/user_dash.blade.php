@extends('index')
@section('title','Log In')
@section('main_content')
<div class="container">
    <div class="col-md-12">
        <div class="row">
            <div class="well" style="background-color: green; color: white; font-weight: bold;">
    <h3>Welcome To User Dashboard.</h3>
</div>
</div>
</div>
</div>
@endsection
