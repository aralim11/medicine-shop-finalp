<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Tbl_user extends Model
{
    //
}
