<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Tbl_user;
use App\Tbl_admin;
use Illuminate\Support\Facades\Redirect;
use Session;
use DB;

session_start();

class WelcomeController extends Controller {

    public function auth_check() {
        $admin_id = Session::get('admin_id');
        $user_id = Session::get('user_id');
        if ($admin_id != NULL) {
            return Redirect::to('/admin-dash')->send();
        } else if ($user_id != NULL) {
            return Redirect::to('/user-dash')->send();
        }
    }

    public function index() {
        $this->auth_check();

        return view('front.page.login');
    }

    public function LoginCheck(Request $request) {

        $email = $request->email;
        $password = $request->password;

        $tbladminchk = DB::table('tbl_admins')
                ->where('admin_email', $email)
                ->where('password', md5($password))
                ->first();

        $tbluserchk = DB::table('tbl_users')
                ->where('user_email', $email)
                ->where('password', md5($password))
                ->first();

        if ($tbladminchk) {

            Session::put('admin_id', $tbladminchk->admin_id);
            Session::put('admin_name', $tbladminchk->admin_name);
            Session::put('acces_lavel', $tbladminchk->acces_lavel);
            return Redirect::to('/admin-dash');
        } else if ($tbluserchk) {

            Session::put('user_id', $tbluserchk->user_id);
            Session::put('user_name', $tbluserchk->user_name);
            Session::put('acces_lavel', $tbluserchk->acces_lavel);
            return Redirect::to('/user-dash');
        } else {

            return Redirect::to('/')->with('message', 'Log In Failed!!');
        }
    }

    public function LogOut() {


        Session::put('admin_id');
        Session::put('admin_name');
        Session::put('user_id');
        Session::put('user_name');
        Session::put('exception', '');
        return Redirect::to('/');
    }

    public function Registration() {

        return view('front.page.registration');
    }

    public function SaveRegistration(Request $request) {

        $tbl_user = new Tbl_user();
        $tbl_user->user_name = $request->name;
        $tbl_user->user_email = $request->email;
        $tbl_user->dob = $request->dob;
        $tbl_user->acces_lavel = 0;
        $tbl_user->password = md5($request->password);
        $tbl_user->save();

        return Redirect::to('/registration')->with('message', 'Registration Successfully!!');
    }

}
