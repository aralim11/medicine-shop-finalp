<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Tbl_admin extends Model
{
    //
}
