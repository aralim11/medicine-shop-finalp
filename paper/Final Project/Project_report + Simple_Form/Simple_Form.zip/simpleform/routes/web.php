<?php

/*
  |--------------------------------------------------------------------------
  | Web Routes
  |--------------------------------------------------------------------------
  |
  | Here is where you can register web routes for your application. These
  | routes are loaded by the RouteServiceProvider within a group which
  | contains the "web" middleware group. Now create something great!
  |
 */

Route::get('/', 'WelcomeController@index');
Route::post('/log-in-check', 'WelcomeController@LoginCheck');

//Log Out
Route::get('/log-out', 'WelcomeController@LogOut');

//Registration
Route::get('/registration', 'WelcomeController@Registration');
Route::post('/save-registration', 'WelcomeController@SaveRegistration');

//Admin
Route::get('/admin-dash', 'AdminController@index');
//User
Route::get('/user-dash', 'UserController@index');
