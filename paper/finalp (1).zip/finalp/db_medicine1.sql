-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 24, 2017 at 09:12 AM
-- Server version: 10.1.28-MariaDB
-- PHP Version: 7.0.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_medicine1`
--

-- --------------------------------------------------------

--
-- Table structure for table `districts`
--

CREATE TABLE `districts` (
  `district_id` int(10) UNSIGNED NOT NULL,
  `district_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `districts`
--

INSERT INTO `districts` (`district_id`, `district_name`, `created_at`, `updated_at`) VALUES
(1, 'Dhaka', NULL, NULL),
(2, 'Tangail', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `invoices`
--

CREATE TABLE `invoices` (
  `id` int(10) UNSIGNED NOT NULL,
  `seller_id` int(11) NOT NULL,
  `invoice_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(9, '2014_10_12_000000_create_users_table', 1),
(10, '2014_10_12_100000_create_password_resets_table', 1),
(11, '2017_09_23_073748_create_tbl_admins_table', 1),
(12, '2017_09_23_092859_create_sellers_table', 1),
(13, '2017_09_23_160047_create_categories_table', 2),
(14, '2017_09_23_174044_create_suppliers_table', 3),
(15, '2017_09_23_205555_create_tbl__products_table', 4),
(20, '2017_09_26_185737_create_purchase_table', 5),
(21, '2017_09_26_200820_create_stock_table', 5),
(22, '2017_09_30_200925_create_districts_table', 6),
(23, '2017_09_30_201121_create_pstations_table', 6),
(25, '2017_10_04_165429_create_tbl_payment_table', 7),
(26, '2017_10_07_100739_create_tbl_warning_table', 8),
(29, '2017_11_13_170530_create_tbl__vouchers_table', 9),
(31, '2017_11_15_065652_create_tb_sales_table', 10),
(33, '2017_11_15_074131_create_invoices_table', 11),
(34, '2017_11_16_190209_create_tbl_registrations_table', 12);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pstations`
--

CREATE TABLE `pstations` (
  `pstation_id` int(10) UNSIGNED NOT NULL,
  `pstation_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `district_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pstations`
--

INSERT INTO `pstations` (`pstation_id`, `pstation_name`, `district_id`, `created_at`, `updated_at`) VALUES
(1, 'Dhanmondi', 1, NULL, NULL),
(2, 'Kolabagan', 1, NULL, NULL),
(3, 'Tejgaon', 1, NULL, NULL),
(4, 'Mirpur', 1, NULL, NULL),
(5, 'Gulshan', 1, NULL, NULL),
(6, 'Motijheel', 1, NULL, NULL),
(7, 'Badda', 1, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `purchase`
--

CREATE TABLE `purchase` (
  `purchase_id` int(10) UNSIGNED NOT NULL,
  `product_id` int(11) NOT NULL,
  `total_purchase_price` double(8,2) NOT NULL,
  `total_advance_price` double(8,2) NOT NULL,
  `total_due_price` double(8,2) NOT NULL,
  `product_qty` int(11) NOT NULL,
  `supplier_id` int(11) NOT NULL,
  `seller_id` int(11) NOT NULL,
  `paymet_status` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `purchase`
--

INSERT INTO `purchase` (`purchase_id`, `product_id`, `total_purchase_price`, `total_advance_price`, `total_due_price`, `product_qty`, `supplier_id`, `seller_id`, `paymet_status`, `created_at`, `updated_at`) VALUES
(1, 6, 2500.00, 2500.00, 0.00, 500, 1, 1, NULL, '2017-11-23 18:00:00', NULL),
(2, 7, 51000.00, 50000.00, 1000.00, 300, 1, 1, NULL, '2017-11-23 18:00:00', NULL),
(3, 4, 400.00, 400.00, 0.00, 200, 3, 1, NULL, '2017-11-23 18:00:00', NULL),
(4, 5, 2500.00, 2000.00, 500.00, 50, 3, 1, NULL, '2017-11-23 18:00:00', NULL),
(5, 1, 200.00, 200.00, 0.00, 100, 4, 1, NULL, '2017-11-23 18:00:00', NULL),
(6, 2, 17500.00, 15000.00, 2500.00, 250, 4, 1, NULL, '2017-11-23 18:00:00', NULL),
(7, 3, 600.00, 500.00, 100.00, 200, 4, 1, NULL, '2017-11-23 18:00:00', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `sellers`
--

CREATE TABLE `sellers` (
  `seller_id` int(10) UNSIGNED NOT NULL,
  `seller_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `shop_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `seller_email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `seller_picture` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `seller_address` text COLLATE utf8mb4_unicode_ci,
  `seller_phone` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `seller_district` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `seller_policeStation` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `seller_label` tinyint(4) DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sellers`
--

INSERT INTO `sellers` (`seller_id`, `seller_name`, `shop_name`, `seller_email`, `seller_picture`, `seller_address`, `seller_phone`, `seller_district`, `seller_policeStation`, `seller_label`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Sajal Kundu', 'Sk Pharmacy', 'sajalkundu098@gmail.com', NULL, NULL, '01708034562', '1', '6', 0, '827ccb0eea8a706c4c34a16891f84e7b', NULL, '2017-11-24 01:16:29', NULL),
(2, 'Nazmul', 'Sheba Pharmcy', 'nazmuldiu8@gmail.com', NULL, NULL, '01713602527', '1', '2', 0, '827ccb0eea8a706c4c34a16891f84e7b', NULL, '2017-11-24 01:19:50', NULL),
(3, 'Mihir', 'Nupur Pharmechy', 'nupurdiu8@gmail.com', NULL, NULL, '01735477378', '1', '5', 0, '827ccb0eea8a706c4c34a16891f84e7b', NULL, '2017-11-24 01:22:38', NULL),
(4, 'Abdul Alim', 'Ma Pharmacy', 'alim.diu16@gmail.com', NULL, NULL, '01675342612', '1', '3', 0, '827ccb0eea8a706c4c34a16891f84e7b', NULL, '2017-11-24 01:24:24', NULL),
(5, 'Solaiman Ahmed', 'Medicine Pharmacy', 'solaiman.cse14@gmail.com', NULL, NULL, '01685695989', '1', '4', 0, '827ccb0eea8a706c4c34a16891f84e7b', NULL, '2017-11-24 01:26:36', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `stock`
--

CREATE TABLE `stock` (
  `stock_id` int(10) UNSIGNED NOT NULL,
  `product_id` int(11) NOT NULL,
  `barcode` varchar(11) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_qty` int(11) NOT NULL,
  `supplier_id` int(11) NOT NULL,
  `seller_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `district_id` int(11) NOT NULL,
  `pstation_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `stock`
--

INSERT INTO `stock` (`stock_id`, `product_id`, `barcode`, `product_qty`, `supplier_id`, `seller_id`, `created_at`, `updated_at`, `district_id`, `pstation_id`) VALUES
(1, 6, '6-0', 500, 1, 1, '2017-11-23 18:00:00', NULL, 1, 6),
(2, 7, '7-0', 300, 1, 1, '2017-11-23 18:00:00', NULL, 1, 6),
(3, 4, '4-0', 200, 3, 1, '2017-11-23 18:00:00', NULL, 1, 6),
(4, 5, '5-0', 50, 3, 1, '2017-11-23 18:00:00', NULL, 1, 6),
(5, 1, '1-0', 100, 4, 1, '2017-11-23 18:00:00', NULL, 1, 6),
(6, 2, '2-0', 250, 4, 1, '2017-11-23 18:00:00', NULL, 1, 6),
(7, 3, '3-0', 200, 4, 1, '2017-11-23 18:00:00', NULL, 1, 6);

-- --------------------------------------------------------

--
-- Table structure for table `suppliers`
--

CREATE TABLE `suppliers` (
  `supplier_id` int(10) UNSIGNED NOT NULL,
  `supplier_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `supplier_description` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `supplier_phone` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` int(11) DEFAULT NULL,
  `seller_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `suppliers`
--

INSERT INTO `suppliers` (`supplier_id`, `supplier_name`, `supplier_description`, `supplier_phone`, `status`, `seller_id`, `created_at`, `updated_at`) VALUES
(1, 'Beximco', 'Today the BEXIMCO Group (\"BEXIMCO\" or the \"Group\") is the largest private sector group in Bangladesh.', '029854488', NULL, 1, '2017-11-24 01:30:22', NULL),
(2, 'Incepta', 'Incepta Pharmaceuticals Ltd. is a leading pharmaceutical company in Bangladesh established in the year 1999.', '028891190', NULL, 1, '2017-11-24 01:31:42', NULL),
(3, 'Square', 'SQUARE today symbolizes a name – a state of mind. But its journey to the growth and prosperity has been no bed of roses.', '029859007', NULL, 1, '2017-11-24 01:33:20', NULL),
(4, 'ACME', 'The ACME Laboratories Ltd. is a leading company for manufacturing world-class and top-quality pharmaceutical products in Bangladesh.', '01713426841', NULL, 1, '2017-11-24 01:35:50', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admins`
--

CREATE TABLE `tbl_admins` (
  `admin_id` int(10) UNSIGNED NOT NULL,
  `admin_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `admin_email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `admin_picture` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `admin_address` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `admin_phone` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `admin_label` tinyint(4) NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_admins`
--

INSERT INTO `tbl_admins` (`admin_id`, `admin_name`, `admin_email`, `admin_picture`, `admin_address`, `admin_phone`, `admin_label`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Alim', 'alim.diu16@gmail.com', '', '', '0999999', 3, '827ccb0eea8a706c4c34a16891f84e7b', NULL, '2017-11-19 18:00:00', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_month`
--

CREATE TABLE `tbl_month` (
  `month_id` int(11) NOT NULL,
  `month_name` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_month`
--

INSERT INTO `tbl_month` (`month_id`, `month_name`) VALUES
(1, 'January'),
(2, 'February'),
(3, 'March'),
(4, 'April'),
(5, 'May'),
(6, 'June'),
(7, 'July'),
(8, 'August'),
(9, 'September'),
(10, 'October'),
(11, 'November'),
(12, 'December');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_payment`
--

CREATE TABLE `tbl_payment` (
  `payment_id` int(10) UNSIGNED NOT NULL,
  `amount` int(50) DEFAULT NULL,
  `seller_id` int(11) NOT NULL,
  `month` int(11) NOT NULL,
  `year` int(11) NOT NULL,
  `transaction_id` varchar(11) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `account_number` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pay_method` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `warning_lavel` int(3) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_registrations`
--

CREATE TABLE `tbl_registrations` (
  `seller_id` int(10) UNSIGNED NOT NULL,
  `seller_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `seller_email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `seller_phone` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `district` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `policestation` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `shop_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_warning`
--

CREATE TABLE `tbl_warning` (
  `warning_id` int(10) UNSIGNED NOT NULL,
  `seller_id` int(11) NOT NULL,
  `month` int(11) NOT NULL,
  `year` int(11) NOT NULL,
  `warning_lavel` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl__products`
--

CREATE TABLE `tbl__products` (
  `product_id` int(10) UNSIGNED NOT NULL,
  `product_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_details` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `purchase_price` double(8,2) NOT NULL,
  `sale_price` int(11) NOT NULL,
  `retail_price` double(8,2) NOT NULL,
  `vat_tax` double(8,2) NOT NULL,
  `product_picture` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `supplier_id` int(11) NOT NULL,
  `seller_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `product_mg` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `district_id` int(11) NOT NULL,
  `pstation_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl__products`
--

INSERT INTO `tbl__products` (`product_id`, `product_name`, `product_details`, `purchase_price`, `sale_price`, `retail_price`, `vat_tax`, `product_picture`, `supplier_id`, `seller_id`, `created_at`, `updated_at`, `product_mg`, `district_id`, `pstation_id`) VALUES
(1, 'A-Cal', 'For the prevention and/or treatment of osteoporosis, fractures, osteomalacia, rickets, tetany, pseudo-parathyroidism.', 2.00, 3, 4.00, 1.20, 'public/product_picture/YND7WV2WKXHC44BkU9iL.jpg', 4, 1, '2017-11-23 18:00:00', NULL, '500mg', 1, 6),
(2, 'Baby_Zink', 'For the treatment of diarrhoea with Oral Rehydration Salts (ORS) in children between 6 months and 5 years of age.', 70.00, 75, 60.00, 2.00, 'public/product_picture/jzVWv62igOe96i1aaQXC.jpg', 4, 1, '2017-11-23 18:00:00', NULL, '20 mg', 1, 6),
(3, 'Cinazin Plus', 'Use in the treatment of vertigo symptoms of various origins', 3.00, 4, 5.00, 0.50, 'public/product_picture/UbJmiA0zYbCTv8s5lm5e.jpg', 4, 1, '2017-11-23 18:00:00', NULL, '20 mg', 1, 6),
(4, 'Ace Plus', 'Fever, headache, migraine, muscle ache, backache, toothache & menstrual pain.', 2.00, 3, 4.00, 0.20, 'public/product_picture/AFFcHzJ7LfndlHfAyGjv.jpg', 3, 1, '2017-11-23 18:00:00', NULL, '500mg', 1, 6),
(5, 'Sedil Injection', 'Anxiety pain from apprehension and depression, acute and chronic stress of life, skeletal muscle spasm and strychnine poisoning.', 50.00, 55, 58.00, 3.00, 'public/product_picture/UckEXNIJjIuj3sXfAsG2.jpg', 3, 1, '2017-11-23 18:00:00', NULL, '30mg', 1, 6),
(6, 'Bexidal', 'There are no adequate and well controlled studies in pregnant women.', 5.00, 6, 7.00, 0.30, 'public/product_picture/FJh5uAlx2SVXjqxz0TSw.jpg', 1, 1, '2017-11-23 18:00:00', NULL, '50mg', 1, 6),
(7, 'Bextram Gold', 'Your body has shown hypersensitivity to any component of the preparation.', 170.00, 175, 178.00, 0.80, 'public/product_picture/rxq4g37QIXGaNouANYBX.jpg', 1, 1, '2017-11-23 18:00:00', NULL, '500mg', 1, 6);

-- --------------------------------------------------------

--
-- Table structure for table `tbl__vouchers`
--

CREATE TABLE `tbl__vouchers` (
  `voucher_id` int(10) UNSIGNED NOT NULL,
  `sale_qty` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `seller_id` int(11) NOT NULL,
  `supplier_id` int(11) NOT NULL,
  `stock_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `total` float NOT NULL,
  `vat` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tb_sales`
--

CREATE TABLE `tb_sales` (
  `product_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `seller_id` int(11) NOT NULL,
  `sale_price` double(8,2) NOT NULL,
  `quantity` int(11) NOT NULL,
  `vat` double(8,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `salesid` int(11) NOT NULL,
  `invoice_id` varchar(11) COLLATE utf8mb4_unicode_ci NOT NULL,
  `total` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `districts`
--
ALTER TABLE `districts`
  ADD PRIMARY KEY (`district_id`);

--
-- Indexes for table `invoices`
--
ALTER TABLE `invoices`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `pstations`
--
ALTER TABLE `pstations`
  ADD PRIMARY KEY (`pstation_id`);

--
-- Indexes for table `purchase`
--
ALTER TABLE `purchase`
  ADD PRIMARY KEY (`purchase_id`);

--
-- Indexes for table `sellers`
--
ALTER TABLE `sellers`
  ADD PRIMARY KEY (`seller_id`),
  ADD UNIQUE KEY `sellers_seller_email_unique` (`seller_email`);

--
-- Indexes for table `stock`
--
ALTER TABLE `stock`
  ADD PRIMARY KEY (`stock_id`);

--
-- Indexes for table `suppliers`
--
ALTER TABLE `suppliers`
  ADD PRIMARY KEY (`supplier_id`);

--
-- Indexes for table `tbl_admins`
--
ALTER TABLE `tbl_admins`
  ADD PRIMARY KEY (`admin_id`),
  ADD UNIQUE KEY `tbl_admins_admin_email_unique` (`admin_email`);

--
-- Indexes for table `tbl_month`
--
ALTER TABLE `tbl_month`
  ADD PRIMARY KEY (`month_id`);

--
-- Indexes for table `tbl_payment`
--
ALTER TABLE `tbl_payment`
  ADD PRIMARY KEY (`payment_id`);

--
-- Indexes for table `tbl_registrations`
--
ALTER TABLE `tbl_registrations`
  ADD PRIMARY KEY (`seller_id`);

--
-- Indexes for table `tbl_warning`
--
ALTER TABLE `tbl_warning`
  ADD PRIMARY KEY (`warning_id`);

--
-- Indexes for table `tbl__products`
--
ALTER TABLE `tbl__products`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `tbl__vouchers`
--
ALTER TABLE `tbl__vouchers`
  ADD PRIMARY KEY (`voucher_id`);

--
-- Indexes for table `tb_sales`
--
ALTER TABLE `tb_sales`
  ADD PRIMARY KEY (`salesid`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `districts`
--
ALTER TABLE `districts`
  MODIFY `district_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `invoices`
--
ALTER TABLE `invoices`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT for table `pstations`
--
ALTER TABLE `pstations`
  MODIFY `pstation_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `purchase`
--
ALTER TABLE `purchase`
  MODIFY `purchase_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `sellers`
--
ALTER TABLE `sellers`
  MODIFY `seller_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `stock`
--
ALTER TABLE `stock`
  MODIFY `stock_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `suppliers`
--
ALTER TABLE `suppliers`
  MODIFY `supplier_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tbl_admins`
--
ALTER TABLE `tbl_admins`
  MODIFY `admin_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_month`
--
ALTER TABLE `tbl_month`
  MODIFY `month_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `tbl_payment`
--
ALTER TABLE `tbl_payment`
  MODIFY `payment_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_registrations`
--
ALTER TABLE `tbl_registrations`
  MODIFY `seller_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_warning`
--
ALTER TABLE `tbl_warning`
  MODIFY `warning_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl__products`
--
ALTER TABLE `tbl__products`
  MODIFY `product_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tbl__vouchers`
--
ALTER TABLE `tbl__vouchers`
  MODIFY `voucher_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tb_sales`
--
ALTER TABLE `tb_sales`
  MODIFY `salesid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
