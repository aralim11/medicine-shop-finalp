<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class tbl_admin extends Model
{
    //
}
