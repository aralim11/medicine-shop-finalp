<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Tbl_Product extends Model
{
    //
}
