<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Pstation extends Model
{
    //
}
